const SKILL_NAME = 'Grupo Aval Skill';
const GET_FACT_MESSAGE = "Hola, Bienvenido a la banca digital de Davivienda. Puedes preguntarme por el saldo de cuenta de ahorros, pagar la tarjeta de crédito, solicitar avances y muchas cosas más!";
const HELP_MESSAGE = '<break time="1s"/> Para consultas de saldo y transacciones debes solicitar tu PIN. Solamente di: <break time="500ms"/> Alexa, enviame un pin. ';
const HELP_REPROMPT = '¿Cómo te puedo ayudar?';
const STOP_MESSAGE = 'Gracias por utilizar nuestros servicios, hasta pronto!';

var AWS = require('aws-sdk');
var sns = new AWS.SNS();
var DBHandler = require("./DBHandler");

var docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = (event, context, callback) => {

    try {
        var request = event.request;

        if (request.type === "LaunchRequest") {
            context.succeed(buildResponse({
                speechText: GET_FACT_MESSAGE + HELP_MESSAGE,
                repromptText: "¿Cómo podemos ayudarte hoy?",
                endSession: false
            }));
        }
        else if (request.type === "IntentRequest") {
            let options = {};

            if (request.intent.name === "inicioSesion") {

                const ID = '1023456789';
                console.log('Entro a Inicio de sesión');
                var pin = makeid();

                var params = {
                    TargetArn: 'arn:aws:sns:us-east-1:684859963665:SNSMiBancoNotification',
                    Message: pin, //type your message
                    Subject: 'PIN' //type your subject
                };


                //publish a message.
                sns.publish(params, function(err_publish, data) {
                    if (err_publish) {
                        console.log('Error sending a message', err_publish);
                    }
                    else {
                        console.log('Sent message:', data.MessageId);
                    }

                });

                /// Update de base de datos al PIN
                var variables1 = [];
                variables1.value = pin;
                variables1.column = 'Pin';
                options.pin = pin;
                DBHandler.updateItems(variables1, function(err2, data2) {
                    if (err2) {
                        context.fail(err2);
                        console.log('aqui hubo error en el update del PIN' + err2);
                        options.speechText = 'Lo siento. No podemos completar tu petición';
                        options.endSession = true;
                        context.succeed(buildResponse(options));
                    }
                    else {
                        console.log('Pin actualizado');
                        options.speechText = 'Te hemos enviado un PIN a tu correo y a tu celular';
                        console.log(options.speechText);
                        console.log('Y el pin es.... ' + options.pin);
                        options.endSession = false;
                        context.succeed(buildResponse2(options));
                    }
                    callback(null, data2);
                });
            }
            else if (request.intent.name === "balanceCuentaAhorros") {

                const ID = '1023456789';
                var pinAttributes = event.session.attributes.pin;
                var pinSlots = request.intent.slots.pin.value;

                if (pinAttributes === pinSlots) {
                    console.log('Si es valido el PIN');

                    DBHandler.getItems(ID, function(err, data) {
                        if (err) {
                            context.fail(err);
                            console.log('aqui4');

                        }
                        else {

                            if (data.Item !== undefined) {
                                options.speechText = 'Tu saldo actual es: COP ' + data.Item.Balance;
                                console.log(options.speechText);
                                options.endSession = false;
                                context.succeed(buildResponse(options));

                            }
                            else {
                                options.speechText = 'Lo siento. No puedo encontrar tu saldo';
                                options.endSession = true;
                                context.succeed(buildResponse(options));
                            }
                        }

                        callback(null, data);
                    });
                }
                else {
                    console.log('No es Valido el PIN');
                    options.speechText = 'Tu PIN no es válido, si áun no tienes tu PIN, puedes solicitarlo diciendo. \'Alexa, Envíame un PIN\'';
                    console.log(options.speechText);
                    options.endSession = false;
                    context.succeed(buildResponse(options));

                }

            }
            else if (request.intent.name === "tarjetaCredito") {

                const ID = '1023456789';
                pinAttributes = event.session.attributes.pin;
                pinSlots = request.intent.slots.pin.value;

                if (pinAttributes === pinSlots) {
                    console.log('Si es valido el PIN');

                    DBHandler.getItems(ID, function(err, data) {
                        if (err) {
                            context.fail(err);
                            console.log('aqui4');

                        }
                        else {

                            if (data.Item !== undefined) {
                                options.speechText = 'Tu saldo a pagar de tarjeta de crédito es: COP ' + data.Item.DeudaTC + '. Tu cupo disponible es: COP '+ (Number(data.Item.Cupo)-Number(data.Item.DeudaTC)) +'. La fecha límite de pago es: ' + data.Item.FechaPagoCredito;
                                console.log(options.speechText);
                                options.endSession = false;
                                context.succeed(buildResponse(options));

                            }
                            else {
                                options.speechText = 'Lo siento. No puedo encontrar tu saldo. Intenta mas tarde';
                                options.endSession = true;
                                context.succeed(buildResponse(options));
                            }
                        }

                        callback(null, data);
                    });
                }
                else {
                    console.log('No es Valido el PIN');
                    options.speechText = 'Tu PIN no es válido, si áun no tienes tu PIN, puedes solicitarlo diciendo. \'Alexa, Envíame un PIN\'';
                    console.log(options.speechText);
                    options.endSession = false;
                    context.succeed(buildResponse(options));

                }


            }
            else if (request.intent.name === "avanceTarjetaCredito") {

                var ID = [];
                pinAttributes = event.session.attributes.pin;
                pinSlots = request.intent.slots.pin.value;
                ID.avance = request.intent.slots.avance.value;
                console.log('avance por :' + request.intent.slots.avance.value);

                if (pinAttributes === pinSlots) {
                    console.log('Si es valido el PIN');

                    var params = {
                        TableName: "alexa-bank-demo",
                        Key: {
                            "Id": "1023456789"
                        },
                        UpdateExpression: "SET #field1 = #field1 + :value1, #field2 = #field2 + :value2",
                        ExpressionAttributeNames: {
                            "#field1": "Balance",
                            "#field2": "DeudaTC"
                        },
                        ExpressionAttributeValues: {
                            ":value1": Number(ID.avance),
                            ":value2": Number(ID.avance)
                        },
                        ReturnValues: "UPDATED_NEW"
                    };

                    docClient.update(params, function(err, data) {
                        if (err) {
                            context.fail(err);
                            console.log('aqui4');
                        }
                        else {
                            options.speechText = 'Tu transacción se ha completado, puedes verificar tu saldo';
                            console.log(options.speechText);
                            options.endSession = false;
                            context.succeed(buildResponse(options));
                        }
                    });
                }
                else {
                    console.log('No es Valido el PIN');
                    options.speechText = 'Tu PIN no es válido, si áun no tienes tu PIN, puedes solicitarlo diciendo. \'Alexa, Envíame un PIN\'';
                    console.log(options.speechText);
                    options.endSession = false;
                    context.succeed(buildResponse(options));

                }

            }
            else if (request.intent.name === "pagoTarjetaCredito") {
                var ID = [];
                pinAttributes = event.session.attributes.pin;
                pinSlots = request.intent.slots.pin.value;
                ID.abono = request.intent.slots.abono.value;
                console.log('abono a crédito por :' + request.intent.slots.abono.value);

                if (pinAttributes === pinSlots) {
                    console.log('Si es valido el PIN');

                    var params = {
                        TableName: "alexa-bank-demo",
                        Key: {
                            "Id": "1023456789"
                        },
                        UpdateExpression: "SET #field1 = #field1 - :value1, #field2 = #field2 - :value2",
                        ExpressionAttributeNames: {
                            "#field1": "Balance",
                            "#field2": "DeudaTC"
                        },
                        ExpressionAttributeValues: {
                            ":value1": Number(ID.abono),
                            ":value2": Number(ID.abono)
                        },
                        ReturnValues: "UPDATED_NEW"
                    };

                    docClient.update(params, function(err, data) {
                        if (err) {
                            context.fail(err);
                            console.log('aqui4');
                        }
                        else {
                            options.speechText = 'Tu transacción se ha completado, puedes verificar tu saldo';
                            console.log(options.speechText);
                            options.endSession = false;
                            context.succeed(buildResponse(options));
                        }
                    });
                }
                else {
                    console.log('No es Valido el PIN');
                    options.speechText = 'Tu PIN no es válido, si áun no tienes tu PIN, puedes solicitarlo diciendo. \'Alexa, Envíame un PIN\'';
                    console.log(options.speechText);
                    options.endSession = false;
                    context.succeed(buildResponse(options));

                }
            }
            else if (request.intent.name === "ayuda") {

                options.speechText = "Puedes decir tarjeta de crédito, saldo de mi cuenta de ahorros. ¿Qué te gustaría hacer? ";
                options.endSession = false;
                context.succeed(buildResponse(options));

            }
            else if (request.intent.name === "valor") {
                console.log('escribir');
                const ID = 1000000;

                DBHandler.putItems(ID, function(err, data) {
                    if (err) {
                        context.fail(err);
                        console.log('aqui4');

                    }
                    else {
                        options.speechText = 'Excelente, tu peticion fue registrada. En 5 minutos recibiras un correo con la respuesta';
                        console.log(options.speechText);
                        options.endSession = true;
                        context.succeed(buildResponse(options));

                    }

                    callback(null, data);
                });


            }
            else if (request.intent.name === "AMAZON.StopIntent" || request.intent.name === "AMAZON.CancelIntent") {
                options.speechText = "Gracias por usar los servicios digitales de Davivienda. Hasta pronto!";
                options.endSession = true;
                context.succeed(buildResponse(options));
            }


            else {
                console.log('error');
                context.fail("Unknown Intent");
            }
        }

        else if (request.type === "SessionEndedRequest") {
            let options = {};
            options.speechText = STOP_MESSAGE;
            options.endSession = true;
            context.succeed(buildResponse(options));
        }
        else {
            context.fail("Unknown Intent type");
        }


    }
    catch (e) {

    }


};


function buildResponse(options) {
    var response = {
        version: "1.0",
        response: {
            outputSpeech: {
                "type": "SSML",
                "ssml": `<speak><prosody rate="medium">${options.speechText}</prosody></speak>`
            },

            shouldEndSession: options.endSession
        }
    };

    if (options.repromptText) {
        response.response.reprompt = {
            outputSpeech: {
                "type": "SSML",
                "ssml": `<speak><prosody rate="medium">${options.repromptText}</prosody></speak>`
            }
        };
    }
    console.log('Response del Builder1: ' + JSON.stringify(response));

    return response;
}

function buildResponse2(options) {
    var response = {
        version: "1.0",
        response: {
            outputSpeech: {
                "type": "SSML",
                "ssml": `<speak><prosody rate="medium">${options.speechText}</prosody></speak>`
            },

            shouldEndSession: options.endSession
        },
        sessionAttributes: {
            "pin": options.pin
        }
    };

    if (options.repromptText) {
        response.response.reprompt = {
            outputSpeech: {
                "type": "SSML",
                "ssml": `<speak><prosody rate="medium">${options.repromptText}</prosody></speak>`
            }
        };
    }

    console.log('Response del Builder2: ' + JSON.stringify(response));

    return response;
}

function makeid() {
    var text = "";
    var possible = "0123456789";

    for (var i = 0; i < 4; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}
