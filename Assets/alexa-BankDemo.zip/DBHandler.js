const AWS = require('aws-sdk');
AWS.config.update({
    region: "us-east-1"
});

var docClient = new AWS.DynamoDB.DocumentClient();
//var dynamodb = new AWS.DynamoDB({apiVersion: '2012-08-10'});

// Nmbre de la tabla de alexa
var table = "alexa-bank-demo";

var getItems = (Id,callback) => {   
  
    var params = {
        TableName: table,
        Key: {
            "Id": '1023456789'
        }
    };

  var retorno = docClient.get(params, function (err, data) {
        console.log('Ejecutó operación de getItems en Tabla alexa-bank-demo');
        callback(err, data);
    });
    
};

var updateItems = (variables,callback) => {   
    console.log('Update function');
    
    console.log('Información a actualizar'+variables.column+' con valor:'+variables.value);
    
    var params = {
        TableName: table,
        Key: {
            "Id": '1023456789'
        },
        UpdateExpression: 'set #a = :x',
        ExpressionAttributeNames: {'#a' : variables.column},
        ExpressionAttributeValues: {
            ':x' : variables.value,
        },
        ReturnValues: 'UPDATED_OLD'
    };
    
    console.log('parametros del put:'+ JSON.stringify(params));

    docClient.update(params, function(err, data) {
        console.log('Ejecutó operación de updateItems en Tabla alexa-bank-demo');
        callback(err, data);  
    });
    
};

var updateItems2 = (avance,callback) => {   
    console.log('Update function');
    
    console.log('Información a actualizar es de avance: '+ avance);
    
    var params = {
        TableName: table,
        Key: {
            "Id": "1023456789"
        },
        UpdateExpression: "SET Balance = Balance + :x",
        ExpressionAttributeValues: {
            ":x" : {
                "N": avance
            }
        },
        ReturnValues: 'UPDATED_NEW'
    };
    
    console.log('parametros del put:'+ JSON.stringify(params));

    docClient.update(params, function(err, data) {
        console.log('Ejecutó operación de updateItems en Tabla alexa-bank-demo');
        callback(err, data);  
    });
    
};



var updatePin = (pin,callback ) => {
    
    var params = {
        TableName: table,
        Key: {
            "Id": '1023456789'
        },
        UpdateExpression: 'set #a = :x',
        ExpressionAttributeNames: {'#a' : 'Pin'},
        ExpressionAttributeValues: {
            ':x' : pin,
        },
        ReturnValues: 'UPDATED_OLD'
    };
    
    console.log('parametros del put:'+ JSON.stringify(params));
    
     docClient.update(params, function(err, data) {
        console.log('Ejecutó operación de updatePin en Tabla alexa-bank-demo');
        callback(err, data);  
    });
    
};

module.exports = {
    getItems,
    updateItems,
    updatePin,
    updateItems2
};